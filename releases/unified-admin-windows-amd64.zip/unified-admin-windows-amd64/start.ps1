# AI Security Gateway - Start Script (PowerShell)
# Starts the backend and optionally the frontend Docker container

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = $ScriptDir

Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║           AI Security Gateway - Starting Services             ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Check if .env exists
if (-not (Test-Path "$InstallDir\.env")) {
    Write-Host "⚠️  .env file not found. Please run install.sh or create .env manually." -ForegroundColor Yellow
    exit 1
}

# Check binary
$Binary = "$InstallDir\unified-admin.exe"
if (-not (Test-Path $Binary)) {
    Write-Host "⚠️  Binary not found: $Binary" -ForegroundColor Yellow
    exit 1
}

# Start backend
Write-Host "[1/2] Starting backend API server..." -ForegroundColor Green
Write-Host ""

# Check if port is in use
$PortInUse = Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue
if ($PortInUse) {
    Write-Host "⚠️  Port 8080 is already in use." -ForegroundColor Yellow
    $Continue = Read-Host "Continue anyway? (y/N)"
    if ($Continue -ne "y" -and $Continue -ne "Y") {
        exit 1
    }
}

# Start backend process (redirect output to log file to keep terminal clean)
Set-Location $InstallDir
$LogFile = Join-Path $InstallDir "backend.log"
$BackendProcess = Start-Process -FilePath $Binary -PassThru -NoNewWindow -RedirectStandardOutput $LogFile -RedirectStandardError $LogFile

Write-Host "✓ Backend started (PID: $($BackendProcess.Id))" -ForegroundColor Green
Write-Host "  API: http://localhost:8080"
Write-Host "  Health: http://localhost:8080/api/v1/health"
Write-Host "  Logs: $LogFile"
Write-Host ""

# Wait a moment for backend to start and check for admin password
Start-Sleep -Seconds 3

# Check if backend is still running
if ($BackendProcess.HasExited) {
    Write-Host "⚠️  Backend process exited. Check logs:" -ForegroundColor Yellow
    Write-Host "  Get-Content $LogFile -Tail 20" -ForegroundColor Cyan
    exit 1
}

# Check for admin password in logs (first-time setup)
if (Test-Path $LogFile) {
    $AdminPasswordSection = Select-String -Path $LogFile -Pattern "DEFAULT ADMIN USER CREATED" -Context 0,12 | Select-Object -First 1
    if ($AdminPasswordSection) {
        Write-Host ""
        Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Yellow
        Write-Host "║          ⚠️  FIRST-TIME SETUP - ADMIN PASSWORD              ║" -ForegroundColor Yellow
        Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Yellow
        Write-Host ""
        
        # Get the lines around the admin password
        $LogContent = Get-Content $LogFile
        $StartIndex = -1
        for ($i = 0; $i -lt $LogContent.Length; $i++) {
            if ($LogContent[$i] -match "DEFAULT ADMIN USER CREATED") {
                $StartIndex = $i
                break
            }
        }
        
        if ($StartIndex -ge 0) {
            $EndIndex = [Math]::Min($StartIndex + 15, $LogContent.Length - 1)
            for ($i = $StartIndex; $i -le $EndIndex; $i++) {
                $line = $LogContent[$i]
                if ($line -match "Temporary Password:") {
                    Write-Host $line -ForegroundColor Red
                } elseif ($line -match "CRITICAL SECURITY NOTICE" -or $line -match "ONE-TIME") {
                    Write-Host $line -ForegroundColor Yellow
                } else {
                    Write-Host $line
                }
            }
        }
        
        Write-Host ""
        Write-Host "⚠️  IMPORTANT: Save this password now - it will NOT be shown again!" -ForegroundColor Yellow
        Write-Host "   Change it immediately after first login."
        Write-Host ""
    }
}

# Optional: Start Docker frontend
if (Test-Path "$InstallDir\docker-compose.frontend.yml") {
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        try {
            docker ps | Out-Null
            # Add clear visual separator and wait a moment for any initial backend logs
            Start-Sleep -Seconds 1
            Write-Host ""
            Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
            Write-Host "[2/2] Starting Docker frontend..." -ForegroundColor Green
            Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
            Write-Host ""
            Write-Host "⚠️  PROMPT: Do you want to start the Docker frontend?" -ForegroundColor Yellow
            Write-Host "   Press Y (or Enter) to start, N to skip" -ForegroundColor Gray
            Write-Host ""
            Write-Host -NoNewline "→ Start Docker frontend? " -ForegroundColor Yellow
            Write-Host -NoNewline "(Y/n): " -ForegroundColor Green
            $StartFrontend = Read-Host
            Write-Host ""
            if ($StartFrontend -ne "n" -and $StartFrontend -ne "N") {
                Set-Location $InstallDir
                docker-compose -f docker-compose.frontend.yml up -d
                Write-Host "✓ Frontend started" -ForegroundColor Green
                Write-Host "  Web UI: http://localhost"
            } else {
                Write-Host "⚠ Skipping Docker frontend" -ForegroundColor Yellow
                Write-Host "  Access backend directly: http://localhost:8080"
            }
        } catch {
            Write-Host "[2/2] Docker daemon not running, skipping frontend" -ForegroundColor Yellow
            Write-Host "  Access backend directly: http://localhost:8080"
        }
    } else {
        Write-Host "[2/2] Docker not available, skipping frontend" -ForegroundColor Yellow
        Write-Host "  Access backend directly: http://localhost:8080"
    }
} else {
    Write-Host "[2/2] Docker compose file not found, skipping frontend" -ForegroundColor Yellow
    Write-Host "  Access backend directly: http://localhost:8080"
}

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║              Services Started Successfully!                ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Access points:"
Write-Host "  Backend API: http://localhost:8080" -ForegroundColor Cyan

$FrontendRunning = docker ps --filter "name=ai-security-gateway-frontend" --format "{{.Names}}" 2>$null
if ($FrontendRunning) {
    Write-Host "  Web UI: http://localhost" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Useful commands:"
Write-Host "  View backend logs: Get-Content $LogFile -Tail 20 -Wait" -ForegroundColor Cyan
Write-Host "  Stop backend: Stop-Process -Id $($BackendProcess.Id)" -ForegroundColor Cyan
Write-Host "  Stop Docker frontend: docker-compose -f docker-compose.frontend.yml down" -ForegroundColor Cyan
Write-Host ""
Write-Host "Note: Backend logs are being written to $LogFile" -ForegroundColor Yellow
Write-Host "      Press Ctrl+C to stop the backend and exit" -ForegroundColor Yellow
Write-Host ""

# Wait for user interrupt
Write-Host "Press Ctrl+C to stop the backend..." -ForegroundColor Yellow
try {
    $BackendProcess.WaitForExit()
} catch {
    Write-Host "`nStopping backend..." -ForegroundColor Yellow
    Stop-Process -Id $BackendProcess.Id -Force
}

