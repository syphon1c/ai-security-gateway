# AI Security Gateway - Quick Start Guide (Windows)

Welcome! This guide will get you up and running in minutes on Windows.

## 📦 What's Included

This release package contains everything you need:

- ✅ **Native Go binary** (`unified-admin.exe`) - Pre-compiled backend, ready to run
- ✅ **Frontend dist/** - Pre-built Vue.js application (for Docker deployment)
- ✅ **Docker configuration** - Complete Docker setup:
  - `Dockerfile.frontend` - Frontend container definition
  - `nginx.conf.template` - Nginx proxy configuration
  - `docker-compose.frontend.yml` - Docker Compose orchestration
- ✅ **Helper scripts** - `start.ps1` PowerShell script for easy starting
- ✅ **configs/** - Backend configuration templates
- ✅ **policies/** - 7 security policy files (250+ detection rules)
- ✅ **.env.example** - Environment variable template with documentation
- ✅ **INSTALL.md** - Comprehensive installation guide

## 🚀 Quick Start (3 Steps)

### Step 1: Configure Environment

**Option A: Manual Configuration (Recommended for Windows)**

1. **Copy environment template:**
   ```powershell
   Copy-Item env.example .env
   ```

2. **Generate secure keys** (using Git Bash, WSL, or PowerShell with OpenSSL):
   ```bash
   # In Git Bash or WSL:
   openssl rand -hex 32        # For JWT_SECRET
   openssl rand -base64 32 | cut -c1-32  # For ENCRYPTION_KEY
   ```

3. **Edit .env file:**
   ```powershell
   notepad .env
   # Or use your favorite editor: code .env, vim .env, etc.
   ```

4. **Update critical values:**
   ```env
   JWT_SECRET=your-generated-jwt-secret-here
   ENCRYPTION_KEY=your-generated-encryption-key-here
   ENVIRONMENT=production  # Change from 'development' for production
   ```

**Option B: Use WSL/Git Bash for install.sh**

If you have WSL or Git Bash installed, you can use the Unix installation script:
```bash
# In Git Bash or WSL
chmod +x install.sh
./install.sh
```

### Step 2: Verify Configuration

Check that your .env file has the required values:

```powershell
# Check JWT_SECRET is set (should be 64+ characters)
Select-String -Path .env -Pattern "^JWT_SECRET="

# Check ENCRYPTION_KEY is set (should be 32 characters)
Select-String -Path .env -Pattern "^ENCRYPTION_KEY="
```

### Step 3: Start the Gateway

**Option A: Using start script (easiest)**
```powershell
.\start.ps1
```

**Option B: Manual start**
```powershell
# PowerShell Terminal 1: Start backend
.\unified-admin.exe

# PowerShell Terminal 2: Start Docker frontend (optional)
docker-compose -f docker-compose.frontend.yml up -d
```

### ✅ Verify It's Working

```powershell
# Check backend API
curl http://localhost:8080/api/v1/health
# Or use Invoke-WebRequest:
Invoke-WebRequest -Uri http://localhost:8080/api/v1/health
```

**Expected response:**
```json
{"status":"ok","version":"...","timestamp":"..."}
```

**Access the web interface:**
- **Docker frontend**: http://localhost
- **Native backend**: http://localhost:8080

---

## 📋 Detailed Setup Options

### Option 1: Native Backend + Docker Frontend (Recommended)

Best for production: Native backend performance + Docker frontend consistency.

**Setup:**
1. Configure .env (see Step 1 above)
2. Start backend: `.\unified-admin.exe` (or use `.\start.ps1`)
3. Start frontend: `docker-compose -f docker-compose.frontend.yml up -d`

**Benefits:**
- ✅ Best performance (native Go binary)
- ✅ Easy frontend updates (just restart container)
- ✅ Configuration changes without rebuilds

### Option 2: Native Backend Only

Perfect for development or when Docker isn't available.

**Setup:**
1. Configure .env (see Step 1 above)
2. Start: `.\unified-admin.exe`
3. Access: http://localhost:8080

**Benefits:**
- ✅ No Docker required
- ✅ Simple setup
- ✅ Embedded web UI included

---

## ⚙️ Configuration

### Critical Environment Variables

**Required (for OAuth):**
- `JWT_SECRET` - Minimum 32 characters, used for JWT token signing
- `ENCRYPTION_KEY` - Exactly 32 characters, used for OAuth encryption

**Server:**
- `SERVER_PORT` - Backend port (default: 8080)
- `ENVIRONMENT` - `development` or `production`
- `ALLOWED_ORIGINS` - CORS origins (required in production)

See `env.example` for complete documentation of all variables.

### Frontend Configuration (Docker)

Edit `frontend\.env` to customize backend connection:

```env
BACKEND_HOST=host.docker.internal:8080
VITE_API_BASE_URL=http://localhost:8080
```

**Changes apply instantly** - just restart:
```powershell
docker-compose -f docker-compose.frontend.yml restart
```

---

## 🔒 Security Checklist

Before deploying to production:

- [ ] Changed `JWT_SECRET` to a strong random value (64+ characters)
- [ ] Changed `ENCRYPTION_KEY` to a strong random value (exactly 32 characters)
- [ ] Set `ENVIRONMENT=production`
- [ ] Configured `ALLOWED_ORIGINS` with your actual domain(s)
- [ ] Reviewed security policies in `policies\` directory
- [ ] Set up OAuth providers (if using authentication)
- [ ] Configured database backup (see INSTALL.md)
- [ ] Set up monitoring and alerting

---

## 🐛 Troubleshooting

### Backend won't start

**"JWT_SECRET not set" or "ENCRYPTION_KEY not set"**
```powershell
# Generate new keys (using Git Bash or WSL)
openssl rand -hex 32        # For JWT_SECRET
openssl rand -base64 32 | cut -c1-32  # For ENCRYPTION_KEY

# Update .env file
notepad .env
```

**Port 8080 already in use**
```powershell
# Check what's using the port
netstat -ano | findstr :8080

# Change port in .env
Add-Content .env "SERVER_PORT=8081"
```

**Execution policy error (PowerShell scripts)**
```powershell
# Allow script execution (run as Administrator)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Frontend can't connect to backend

**Check backend is running:**
```powershell
Invoke-WebRequest -Uri http://localhost:8080/api/v1/health
```

**Update frontend\.env:**
```powershell
notepad frontend\.env
# Ensure BACKEND_HOST=host.docker.internal:8080

# Restart frontend
docker-compose -f docker-compose.frontend.yml restart
```

### Docker issues

**Docker daemon not running**
- Start Docker Desktop from Start menu
- Wait for Docker to fully start (system tray icon)

**Port 80 in use**
```powershell
# Use different port
docker run -d --name ai-security-gateway-frontend -p 3000:80 `
  -v "${PWD}/frontend/.env:/app/config/.env:ro" `
  --add-host host.docker.internal:host-gateway `
  ai-security-gateway-frontend:local
```

### Common Windows Issues

**File path issues:**
- Use forward slashes `/` or escaped backslashes `\\` in paths
- PowerShell handles both, but some commands prefer one format

**Permission issues:**
- Run PowerShell as Administrator if needed
- Check Windows Defender isn't blocking the executable

---

## 📚 Next Steps

- **📖 INSTALL.md** - Comprehensive installation and configuration guide
- **📖 README.md** - Project overview and features
- **📖 docs\** - Detailed documentation for all features

### What's Next?

1. ✅ **Access Web Interface** - http://localhost:8080 (or http://localhost with Docker)
2. ✅ **Create Your First Proxy** - Use the web interface to set up an MCP or LLM proxy
3. ✅ **Configure Security Policies** - Review and customize policies in `policies\` directory
4. ✅ **Set Up OAuth Authentication** (optional) - Configure OAuth providers for user authentication:
   - **Gateway OAuth (2LO)**: Authenticate users to the Gateway via OAuth providers (GitHub, Google, Okta, etc.)
   - **MCP Server OAuth Delegation (3LO)**: Enable delegated OAuth access for OAuth-enabled MCP servers, allowing Gateway to authenticate on behalf of users
   - See `docs\user-guides\oauth-delegation\` for detailed OAuth delegation guides
5. ✅ **Review Documentation** - Explore `docs\` directory for advanced features

---

## 💡 Tips

- **Use `.\start.ps1`** for easy starting (handles both backend and frontend)
- **Check logs** if something goes wrong:
  - Backend: Console output
  - Frontend: `docker logs ai-security-gateway-frontend`
- **Production deployment**: See INSTALL.md for service installation using NSSM
- **Use WSL or Git Bash** if you prefer Unix-style commands

---

**Need help?** Check INSTALL.md for detailed troubleshooting or open an issue on GitHub.
