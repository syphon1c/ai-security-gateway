# AI Security Gateway - Installation Guide

This comprehensive guide will help you install and configure the AI Security Gateway on your system.

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Quick Installation](#quick-installation)
3. [Detailed Installation Steps](#detailed-installation-steps)
4. [Configuration](#configuration)
5. [Service Installation](#service-installation)
6. [Verification](#verification)
7. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements

- **CPU**: 1 core (2+ recommended)
- **RAM**: 512MB (1GB+ recommended)
- **Disk**: 100MB free space
- **Network**: Internet connection for OAuth providers (optional)

### Operating Systems

- **Linux**: x86_64 (amd64) or ARM64
  - Ubuntu 20.04+, Debian 10+, CentOS 7+, RHEL 7+
  - Alpine Linux 3.12+
- **macOS**: 10.15+ (Intel or Apple Silicon)
- **Windows**: Windows 10+ (amd64)

### Dependencies

- **Docker** (optional, for frontend deployment)
  - Docker 20.10+ and Docker Compose 1.29+
  - Required only if using Docker frontend deployment

---

## Quick Installation

### Automated Installation (Recommended)

The easiest way to get started is using the provided installation script:

```bash
# 1. Download and extract release
curl -LO https://github.com/syphon1c/ai-security-gateway/releases/latest/download/unified-admin-linux-amd64.tar.gz
tar -xzf unified-admin-linux-amd64.tar.gz
cd unified-admin-linux-amd64

# 2. Run installation script
chmod +x install.sh
./install.sh

# 3. Verify installation
./verify.sh

# 4. Start the gateway
./start.sh
```

The installation script will:
- ✅ Generate secure JWT_SECRET and ENCRYPTION_KEY
- ✅ Create and configure .env file
- ✅ Set up required directories
- ✅ Optionally install as a system service

---

## Detailed Installation Steps

### Step 1: Download Release

Download the appropriate release for your platform from the [GitHub Releases](https://github.com/syphon1c/ai-security-gateway/releases) page:

**Linux (AMD64):**
```bash
curl -LO https://github.com/syphon1c/ai-security-gateway/releases/latest/download/unified-admin-linux-amd64.tar.gz
tar -xzf unified-admin-linux-amd64.tar.gz
cd unified-admin-linux-amd64
```

**Linux (ARM64):**
```bash
curl -LO https://github.com/syphon1c/ai-security-gateway/releases/latest/download/unified-admin-linux-arm64.tar.gz
tar -xzf unified-admin-linux-arm64.tar.gz
cd unified-admin-linux-arm64
```

**macOS (Apple Silicon):**
```bash
curl -LO https://github.com/syphon1c/ai-security-gateway/releases/latest/download/unified-admin-darwin-arm64.tar.gz
tar -xzf unified-admin-darwin-arm64.tar.gz
cd unified-admin-darwin-arm64
```

**macOS (Intel):**
```bash
curl -LO https://github.com/syphon1c/ai-security-gateway/releases/latest/download/unified-admin-darwin-amd64.tar.gz
tar -xzf unified-admin-darwin-amd64.tar.gz
cd unified-admin-darwin-amd64
```

**Windows:**
1. Download `unified-admin-windows-amd64.zip`
2. Extract to a folder (e.g., `C:\ai-security-gateway`)
3. Open PowerShell in that folder

### Step 2: Verify Package Contents

Ensure all required files are present:

```bash
# Linux/macOS
ls -la
# Should show: unified-admin, frontend/, configs/, policies/, .env.example, etc.

# Windows
dir
# Should show: unified-admin.exe, frontend\, configs\, policies\, etc.
```

**Required files:**
- ✅ Binary executable (`unified-admin` or `unified-admin.exe`)
- ✅ `frontend/dist/` directory (pre-built frontend)
- ✅ `configs/` directory (configuration templates)
- ✅ `policies/` directory (security policies)
- ✅ `.env.example` (environment template)
- ✅ `docker-compose.frontend.yml` (Docker frontend setup)
- ✅ `QUICKSTART.md` (quick start guide)

### Step 3: Make Binary Executable (Linux/macOS)

```bash
chmod +x unified-admin
```

### Step 4: Configure Environment

#### Option A: Use Installation Script (Recommended)

```bash
./install.sh
```

#### Option B: Manual Configuration

1. **Copy environment template:**
   ```bash
   cp .env.example .env
   ```

2. **Generate secure keys:**
   ```bash
   # Generate JWT secret (64 hex characters)
   openssl rand -hex 32
   
   # Generate encryption key (32 characters)
   openssl rand -base64 32 | cut -c1-32
   ```

3. **Edit .env file:**
   ```bash
   nano .env  # or vi, vim, code, etc.
   ```

4. **Update critical values:**
   ```env
   JWT_SECRET=your-generated-jwt-secret-here
   ENCRYPTION_KEY=your-generated-encryption-key-here
   ENVIRONMENT=production  # Change from 'development' for production
   ```

### Step 5: Create Data Directory

```bash
mkdir -p data
```

---

## Configuration

### Environment Variables

The `.env` file contains all configuration. Key variables:

#### Required (for OAuth)

- **JWT_SECRET**: Minimum 32 characters, used for JWT token signing
- **ENCRYPTION_KEY**: Exactly 32 characters, used for OAuth encryption

#### Server Configuration

- **SERVER_HOST**: Server bind address (default: `0.0.0.0`)
- **SERVER_PORT**: Server port (default: `8080`)
- **ENVIRONMENT**: `development` or `production`
- **ALLOWED_ORIGINS**: CORS allowed origins (comma-separated)

#### Database Configuration

- **DATABASE_PATH**: SQLite database file path (default: `./data/security.db`)

#### Optional: OAuth Providers

Configure OAuth providers as needed:
- `OAUTH_GITHUB_CLIENT_ID` / `OAUTH_GITHUB_CLIENT_SECRET`
- `OAUTH_GOOGLE_CLIENT_ID` / `OAUTH_GOOGLE_CLIENT_SECRET`
- `OAUTH_MICROSOFT_CLIENT_ID` / `OAUTH_MICROSOFT_CLIENT_SECRET`
- And more...

See `.env.example` for complete list and documentation.

### Advanced Configuration

For advanced settings, copy and edit the YAML config:

```bash
cp configs/config.example.yaml configs/config.yaml
nano configs/config.yaml
```

---

## Service Installation

### Linux (systemd)

1. **Copy service file:**
   ```bash
   sudo cp ai-security-gateway.service /etc/systemd/system/
   ```

2. **Edit service file** to update paths:
   ```bash
   sudo nano /etc/systemd/system/ai-security-gateway.service
   ```
   
   Update these lines:
   ```ini
   WorkingDirectory=/opt/ai-security-gateway
   ExecStart=/usr/local/bin/unified-admin
   EnvironmentFile=/opt/ai-security-gateway/.env
   ```

3. **Install binary:**
   ```bash
   sudo cp unified-admin /usr/local/bin/
   sudo chmod +x /usr/local/bin/unified-admin
   ```

4. **Move application files:**
   ```bash
   sudo mkdir -p /opt/ai-security-gateway
   sudo cp -r . /opt/ai-security-gateway/
   sudo chown -R aigateway:aigateway /opt/ai-security-gateway
   ```

5. **Create service user:**
   ```bash
   sudo useradd -r -s /bin/false aigateway
   ```

6. **Enable and start service:**
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable ai-security-gateway
   sudo systemctl start ai-security-gateway
   ```

7. **Check status:**
   ```bash
   sudo systemctl status ai-security-gateway
   ```

### macOS (launchd)

1. **Copy plist file:**
   ```bash
   cp com.aisecuritygateway.unified-admin.plist ~/Library/LaunchAgents/
   ```

2. **Edit plist** to update paths:
   ```bash
   nano ~/Library/LaunchAgents/com.aisecuritygateway.unified-admin.plist
   ```
   
   Update paths to match your installation directory.

3. **Load service:**
   ```bash
   launchctl load ~/Library/LaunchAgents/com.aisecuritygateway.unified-admin.plist
   launchctl start com.aisecuritygateway.unified-admin
   ```

4. **Check status:**
   ```bash
   launchctl list | grep unified-admin
   ```

### Windows (NSSM - Non-Sucking Service Manager)

1. **Download NSSM:**
   - Download from https://nssm.cc/download
   - Extract to a folder (e.g., `C:\nssm`)

2. **Install service:**
   ```powershell
   C:\nssm\win64\nssm.exe install AI-Security-Gateway
   ```

3. **Configure service:**
   - **Path**: Full path to `unified-admin.exe`
   - **Startup directory**: Directory containing the binary
   - **Arguments**: (leave empty)
   - **Environment**: Add `JWT_SECRET` and `ENCRYPTION_KEY` variables

4. **Start service:**
   ```powershell
   C:\nssm\win64\nssm.exe start AI-Security-Gateway
   ```

---

## Verification

### Run Verification Script

```bash
# Linux/macOS
./verify.sh

# Windows (PowerShell)
# Manual verification - see below
```

### Manual Verification

1. **Check binary:**
   ```bash
   ./unified-admin --version
   # or
   ./unified-admin --help
   ```

2. **Check configuration:**
   ```bash
   # Verify .env exists and has required values
   grep -E "^JWT_SECRET=|^ENCRYPTION_KEY=" .env
   ```

3. **Test API (after starting):**
   ```bash
   curl http://localhost:8080/api/v1/health
   ```

4. **Check logs:**
   ```bash
   # If running as service
   sudo journalctl -u ai-security-gateway -f  # Linux
   tail -f ~/Library/Logs/ai-security-gateway/daemon.log  # macOS
   ```

---

## Troubleshooting

### Common Issues

#### 1. "JWT_SECRET not set" or "ENCRYPTION_KEY not set"

**Problem:** Required environment variables are missing or invalid.

**Solution:**
```bash
# Generate new keys
JWT_SECRET=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(openssl rand -base64 32 | cut -c1-32)

# Update .env file
echo "JWT_SECRET=$JWT_SECRET" >> .env
echo "ENCRYPTION_KEY=$ENCRYPTION_KEY" >> .env
```

#### 2. Port 8080 Already in Use

**Problem:** Another service is using port 8080.

**Solution:**
```bash
# Option 1: Change port in .env
echo "SERVER_PORT=8081" >> .env

# Option 2: Find and stop conflicting service
# Linux
sudo lsof -i :8080
sudo kill <PID>

# macOS
lsof -i :8080
kill <PID>
```

#### 3. Permission Denied

**Problem:** Binary is not executable or insufficient permissions.

**Solution:**
```bash
# Make executable
chmod +x unified-admin

# Check permissions
ls -l unified-admin
```

#### 4. Frontend Can't Connect to Backend

**Problem:** Frontend Docker container can't reach backend API.

**Solution:**
```bash
# Check backend is running
curl http://localhost:8080/api/v1/health

# Update frontend/.env
nano frontend/.env
# Set BACKEND_HOST to your machine's IP (not localhost) on Linux
# BACKEND_HOST=192.168.1.100:8080

# Restart frontend
docker-compose -f docker-compose.frontend.yml restart
```

#### 5. Database Locked or Permission Error

**Problem:** SQLite database file permissions issue.

**Solution:**
```bash
# Check database file
ls -l data/security.db

# Fix permissions
chmod 644 data/security.db
chown $USER:$USER data/security.db

# Ensure data directory exists
mkdir -p data
```

### Getting Help

- **Documentation**: See `QUICKSTART.md` for quick reference
- **GitHub Issues**: https://github.com/syphon1c/ai-security-gateway/issues
- **Logs**: Check application logs for detailed error messages

---

## Next Steps

After successful installation:

1. ✅ **Access Web Interface**: http://localhost:8080 (or your configured port)
2. ✅ **Create First Proxy**: Follow the web interface wizard
3. ✅ **Configure Security Policies**: Review and customize policies
4. ✅ **Set Up OAuth** (optional): Configure OAuth providers for authentication
5. ✅ **Review Documentation**: See `docs/` directory for detailed guides

For quick start instructions, see **QUICKSTART.md**.

