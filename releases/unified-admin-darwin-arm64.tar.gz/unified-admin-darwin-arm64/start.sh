#!/bin/bash
# AI Security Gateway - Start Script
# Starts the backend and optionally the frontend Docker container

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$SCRIPT_DIR"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║           AI Security Gateway - Starting Services             ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if .env exists
if [ ! -f "$INSTALL_DIR/.env" ]; then
    echo -e "${YELLOW}⚠️  .env file not found. Running install.sh first...${NC}"
    if [ -f "$INSTALL_DIR/install.sh" ]; then
        bash "$INSTALL_DIR/install.sh"
    else
        echo -e "${YELLOW}⚠️  install.sh not found. Please create .env manually.${NC}"
        exit 1
    fi
fi

# Check binary
if [ -f "$INSTALL_DIR/unified-admin" ]; then
    BINARY="$INSTALL_DIR/unified-admin"
    chmod +x "$BINARY"
elif [ -f "$INSTALL_DIR/unified-admin.exe" ]; then
    BINARY="$INSTALL_DIR/unified-admin.exe"
else
    echo -e "${YELLOW}⚠️  Binary not found in $INSTALL_DIR${NC}"
    exit 1
fi

# Start backend
echo -e "${GREEN}[1/2]${NC} Starting backend API server..."
echo ""

# The backend honours SERVER_PORT from .env; keep the port check and the
# readiness poll in step with it
PORT=$(grep -E "^SERVER_PORT=" "$INSTALL_DIR/.env" 2>/dev/null | cut -d= -f2)
PORT=${PORT:-8080}

# Check if already running
if command -v lsof &> /dev/null; then
    if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️  Port $PORT is already in use.${NC}"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
fi

# Start backend in background (redirect output to log file to keep terminal clean)
cd "$INSTALL_DIR"
LOG_FILE="$INSTALL_DIR/backend.log"
"$BINARY" > "$LOG_FILE" 2>&1 &
BACKEND_PID=$!

echo -e "${GREEN}✓${NC} Backend started (PID: $BACKEND_PID)"
echo "  API: http://localhost:$PORT"
echo "  Health: http://localhost:$PORT/api/v1/health"
echo "  Logs: $LOG_FILE"
echo ""

# Wait for the backend to finish starting up. First boot runs migrations and
# seeds the admin user, which can take well over a few seconds; the password
# banner is written to the log BEFORE the server starts listening, so once
# the health endpoint answers the scan below is definitive either way.
STARTUP_WAIT=60
for i in $(seq 1 $STARTUP_WAIT); do
    if ! kill -0 $BACKEND_PID 2>/dev/null; then
        echo -e "${YELLOW}⚠️  Backend process exited. Check logs:${NC}"
        echo -e "  ${BLUE}tail -20 $LOG_FILE${NC}"
        exit 1
    fi
    if grep -q "DEFAULT ADMIN USER CREATED" "$LOG_FILE" 2>/dev/null; then
        break
    fi
    if command -v curl >/dev/null 2>&1 && curl -sf http://localhost:$PORT/api/v1/health >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

# Check for admin password in logs (first-time setup)
ADMIN_PASSWORD_SECTION=$(grep -A 12 "DEFAULT ADMIN USER CREATED" "$LOG_FILE" 2>/dev/null | head -60)
if [ -n "$ADMIN_PASSWORD_SECTION" ]; then
    echo ""
    echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║          ⚠️  FIRST-TIME SETUP - ADMIN PASSWORD              ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "$ADMIN_PASSWORD_SECTION" | while IFS= read -r line; do
        # Highlight the password line
        if echo "$line" | grep -q "Temporary Password:"; then
            echo -e "${RED}$line${NC}"
        elif echo "$line" | grep -q "CRITICAL SECURITY NOTICE" || echo "$line" | grep -q "ONE-TIME"; then
            echo -e "${YELLOW}$line${NC}"
        else
            echo "$line"
        fi
    done
    echo ""
    echo -e "${YELLOW}⚠️  IMPORTANT:${NC} Save this password now - it will NOT be shown again!"
    echo -e "   Change it immediately after first login."
    echo ""
fi

# Optional: Start Docker frontend
if [ -f "$INSTALL_DIR/docker-compose.frontend.yml" ]; then
    if command -v docker &> /dev/null && docker ps &> /dev/null; then
        # Add clear visual separator and wait a moment for any initial backend logs
        sleep 1
        echo ""
        echo -e "${BLUE}═══════════════════════════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}[2/2]${NC} Starting Docker frontend..."
        echo -e "${BLUE}═══════════════════════════════════════════════════════════════════════════════${NC}"
        echo ""
        echo -e "${YELLOW}⚠️  PROMPT:${NC} Do you want to start the Docker frontend?"
        echo -e "   ${GREEN}Press Y${NC} (or Enter) to start, ${RED}N${NC} to skip"
        echo ""
        echo -n -e "${YELLOW}→ Start Docker frontend?${NC} ${GREEN}(Y/n):${NC} "
        read -n 1 -r
        echo ""
        echo ""
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            cd "$INSTALL_DIR"
            # Stop existing container if running
            if docker ps | grep -q ai-security-gateway-frontend; then
                echo -e "${BLUE}Stopping existing frontend container...${NC}"
                docker-compose -f docker-compose.frontend.yml down
            fi
            # Rebuild without cache to ensure latest frontend version
            echo -e "${BLUE}Building frontend Docker image (no cache)...${NC}"
            docker-compose -f docker-compose.frontend.yml build --no-cache
            docker-compose -f docker-compose.frontend.yml up -d
            echo -e "${GREEN}✓${NC} Frontend started"
            echo "  Web UI: http://localhost"
        else
            echo -e "${YELLOW}⚠${NC} Skipping Docker frontend"
            echo "  Access backend directly: http://localhost:8080"
        fi
    else
        echo -e "${YELLOW}[2/2]${NC} Docker not available, skipping frontend"
        echo "  Access backend directly: http://localhost:8080"
    fi
else
    echo -e "${YELLOW}[2/2]${NC} Docker compose file not found, skipping frontend"
    echo "  Access backend directly: http://localhost:8080"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              Services Started Successfully!                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "Access points:"
echo -e "  ${BLUE}Backend API:${NC} http://localhost:8080"
if [ -f "$INSTALL_DIR/docker-compose.frontend.yml" ] && docker ps | grep -q ai-security-gateway-frontend; then
    echo -e "  ${BLUE}Web UI:${NC} http://localhost"
fi
echo ""
echo -e "Useful commands:"
echo -e "  ${BLUE}View backend logs:${NC} tail -f $LOG_FILE"
echo -e "  ${BLUE}Stop backend:${NC} kill $BACKEND_PID"
echo -e "  ${BLUE}Stop Docker frontend:${NC} docker-compose -f docker-compose.frontend.yml down"
echo ""
echo -e "${YELLOW}Note:${NC} Backend logs are being written to $LOG_FILE"
echo -e "      Press ${BLUE}Ctrl+C${NC} to stop the backend and exit"
echo ""

# Wait for interrupt
trap "echo ''; echo 'Stopping backend...'; kill $BACKEND_PID 2>/dev/null; exit 0" INT TERM

# Keep script running
wait $BACKEND_PID

