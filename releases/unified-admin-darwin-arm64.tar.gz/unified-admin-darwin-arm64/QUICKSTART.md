# AI Security Gateway - Quick Start Guide

Welcome! This guide will get you up and running in minutes.

## 📦 What's Included

This release package contains everything you need:

- ✅ **Native Go binary** (`unified-admin`) - Pre-compiled backend, ready to run
- ✅ **Frontend dist/** - Pre-built Vue.js application (for Docker deployment)
- ✅ **Docker configuration** - Complete Docker setup:
  - `Dockerfile.frontend` - Frontend container definition
  - `nginx.conf.template` - Nginx proxy configuration
  - `docker-compose.frontend.yml` - Docker Compose orchestration
- ✅ **Helper scripts** - `install.sh`, `verify.sh`, `start.sh` for easy setup
- ✅ **Service files** - Systemd/Launchd service files for production
- ✅ **configs/** - Backend configuration templates
- ✅ **policies/** - 7 security policy files (250+ detection rules)
- ✅ **.env.example** - Environment variable template with documentation
- ✅ **INSTALL.md** - Comprehensive installation guide

## 🚀 Quick Start (3 Steps)

### Step 1: Run Installation Script (Recommended)

The easiest way to get started:

```bash
# Make scripts executable
chmod +x install.sh verify.sh start.sh

# Run installation (generates secure keys, sets up .env)
./install.sh
```

The script will:
- ✅ Generate secure JWT_SECRET and ENCRYPTION_KEY automatically
- ✅ Create and configure .env file
- ✅ Set up required directories
- ✅ Optionally install as a system service

### Step 2: Verify Installation

```bash
# Check everything is configured correctly
./verify.sh
```

This will verify:
- ✅ Binary is executable
- ✅ .env file exists with secure keys
- ✅ Required directories exist
- ✅ Port availability
- ✅ Docker setup (if applicable)

### Step 3: Start the Gateway

**Option A: Using start script (easiest)**
```bash
./start.sh
```

**Option B: Manual start**
```bash
# Terminal 1: Start backend
./unified-admin

# Terminal 2: Start Docker frontend (optional)
docker-compose -f docker-compose.frontend.yml up -d
```

**Option C: Using system service (production)**
```bash
# Linux
sudo systemctl start ai-security-gateway

# macOS
launchctl start com.aisecuritygateway.unified-admin
```

### ✅ Verify It's Working

```bash
# Check backend API
curl http://localhost:8080/api/v1/health

# Expected response:
# {"status":"ok","version":"...","timestamp":"..."}
```

**Access the web interface:**
- **Docker frontend**: http://localhost
- **Native backend**: http://localhost:8080

---

## 📋 Detailed Setup Options

### Option 1: Native Backend + Docker Frontend (Recommended)

Best for production: Native backend performance + Docker frontend consistency.

**Setup:**
1. Run `./install.sh` (or manually configure .env)
2. Start backend: `./unified-admin` (or use `./start.sh`)
3. Start frontend: `docker-compose -f docker-compose.frontend.yml up -d`

**Benefits:**
- ✅ Best performance (native Go binary)
- ✅ Easy frontend updates (just restart container)
- ✅ Configuration changes without rebuilds

### Option 2: Native Backend Only

Perfect for development or when Docker isn't available.

**Setup:**
1. Run `./install.sh` (or manually configure .env)
2. Start: `./unified-admin`
3. Access: http://localhost:8080

**Benefits:**
- ✅ No Docker required
- ✅ Simple setup
- ✅ Embedded web UI included

### Option 3: Manual Configuration

If you prefer to configure manually:

```bash
# 1. Copy environment template
cp env.example .env

# 2. Generate secure keys
JWT_SECRET=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(openssl rand -base64 32 | cut -c1-32)

# 3. Edit .env and set the keys
nano .env

# 4. Start
./unified-admin
```

---

## ⚙️ Configuration

### Critical Environment Variables

**Required (for OAuth):**
- `JWT_SECRET` - Minimum 32 characters, used for JWT token signing
- `ENCRYPTION_KEY` - Exactly 32 characters, used for OAuth encryption

**Server:**
- `SERVER_PORT` - Backend port (default: 8080)
- `ENVIRONMENT` - `development` or `production`
- `ALLOWED_ORIGINS` - CORS origins (required in production)

See `env.example` for complete documentation of all variables.

### Frontend Configuration (Docker)

Edit `frontend/.env` to customize backend connection:

```env
BACKEND_HOST=host.docker.internal:8080
VITE_API_BASE_URL=http://localhost:8080
```

**⚠️ Linux Note:** `host.docker.internal` may not work on Linux. Use your machine's IP address:
```env
BACKEND_HOST=192.168.1.100:8080  # Replace with your IP
```

**Changes apply instantly** - just restart:
```bash
docker-compose -f docker-compose.frontend.yml restart
```

---

## 🔒 Security Checklist

Before deploying to production:

- [ ] Changed `JWT_SECRET` to a strong random value (64+ characters)
- [ ] Changed `ENCRYPTION_KEY` to a strong random value (exactly 32 characters)
- [ ] Set `ENVIRONMENT=production`
- [ ] Configured `ALLOWED_ORIGINS` with your actual domain(s)
- [ ] Reviewed security policies in `policies/` directory
- [ ] Set up OAuth providers (if using authentication)
- [ ] Configured database backup (see INSTALL.md)
- [ ] Set up monitoring and alerting

---

## 🐛 Troubleshooting

### Backend won't start

**"JWT_SECRET not set" or "ENCRYPTION_KEY not set"**
```bash
# Generate new keys
openssl rand -hex 32  # For JWT_SECRET
openssl rand -base64 32 | cut -c1-32  # For ENCRYPTION_KEY

# Update .env file
nano .env
```

**Port 8080 already in use**
```bash
# Check what's using the port
lsof -i :8080  # macOS/Linux

# Change port in .env
echo "SERVER_PORT=8081" >> .env
```

**Permission denied**
```bash
chmod +x unified-admin
```

### Frontend can't connect to backend

**Check backend is running:**
```bash
curl http://localhost:8080/api/v1/health
```

**Update frontend/.env:**
```bash
# On Linux, use your machine's IP instead of host.docker.internal
nano frontend/.env
# Set BACKEND_HOST=192.168.1.100:8080  # Your IP

# Restart frontend
docker-compose -f docker-compose.frontend.yml restart
```

### Docker issues

**Docker daemon not running**
```bash
# Start Docker
sudo systemctl start docker  # Linux
# Or start Docker Desktop on macOS/Windows
```

**Port 80 in use**
```bash
# Use different port
docker run -d --name ai-security-gateway-frontend -p 3000:80 \
  -v "$(pwd)/frontend/.env:/app/config/.env:ro" \
  --add-host host.docker.internal:host-gateway \
  ai-security-gateway-frontend:local
```

### Verification fails

Run `./verify.sh` to see detailed error messages. Common fixes:

- Missing .env file → Run `./install.sh`
- Invalid keys → Regenerate with `openssl`
- Port in use → Change `SERVER_PORT` in .env
- Binary not executable → `chmod +x unified-admin`

---

## 📚 Next Steps

- **📖 INSTALL.md** - Comprehensive installation and configuration guide
- **📖 README.md** - Project overview and features
- **📖 docs/** - Detailed documentation for all features

### What's Next?

1. ✅ **Access Web Interface** - http://localhost:8080 (or http://localhost with Docker)
2. ✅ **Create Your First Proxy** - Use the web interface to set up an MCP or LLM proxy
3. ✅ **Configure Security Policies** - Review and customize policies in `policies/` directory
4. ✅ **Set Up OAuth Authentication** (optional) - Configure OAuth providers for user authentication:
   - **Gateway OAuth (2LO)**: Authenticate users to the Gateway via OAuth providers (GitHub, Google, Okta, etc.)
   - **MCP Server OAuth Delegation (3LO)**: Enable delegated OAuth access for OAuth-enabled MCP servers, allowing Gateway to authenticate on behalf of users
   - See `docs/user-guides/oauth-delegation/` for detailed OAuth delegation guides
5. ✅ **Review Documentation** - Explore `docs/` directory for advanced features

---

## 💡 Tips

- **Use `./verify.sh`** regularly to check your setup
- **Use `./start.sh`** for easy starting (handles both backend and frontend)
- **Check logs** if something goes wrong:
  - Backend: Console output or systemd journal
  - Frontend: `docker logs ai-security-gateway-frontend`
- **Production deployment**: See INSTALL.md for service installation and best practices

---

**Need help?** Check INSTALL.md for detailed troubleshooting or open an issue on GitHub.
