#!/bin/bash
# AI Security Gateway - Verification Script
# Checks if installation is correct and ready to run

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$SCRIPT_DIR"

ERRORS=0
WARNINGS=0

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        AI Security Gateway - Verification Script             ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check 1: Binary exists and is executable
echo -e "${BLUE}[1/8]${NC} Checking binary..."
if [ -f "$INSTALL_DIR/unified-admin" ]; then
    if [ -x "$INSTALL_DIR/unified-admin" ]; then
        echo -e "  ${GREEN}✓${NC} unified-admin exists and is executable"
    else
        echo -e "  ${RED}✗${NC} unified-admin exists but is not executable"
        echo "    Fix: chmod +x $INSTALL_DIR/unified-admin"
        ((ERRORS++))
    fi
elif [ -f "$INSTALL_DIR/unified-admin.exe" ]; then
    echo -e "  ${GREEN}✓${NC} unified-admin.exe found (Windows)"
else
    echo -e "  ${RED}✗${NC} Binary not found"
    ((ERRORS++))
fi

# Check 2: .env file exists
echo ""
echo -e "${BLUE}[2/8]${NC} Checking configuration..."
if [ -f "$INSTALL_DIR/.env" ]; then
    echo -e "  ${GREEN}✓${NC} .env file exists"
    
    # Check critical variables
    if grep -q "^JWT_SECRET=" "$INSTALL_DIR/.env"; then
        JWT_SECRET=$(grep "^JWT_SECRET=" "$INSTALL_DIR/.env" | cut -d'=' -f2)
        if [ "$JWT_SECRET" == "CHANGE_THIS_IMMEDIATELY" ] || [ -z "$JWT_SECRET" ] || [ ${#JWT_SECRET} -lt 32 ]; then
            echo -e "  ${RED}✗${NC} JWT_SECRET is not set or too short (minimum 32 characters)"
            ((ERRORS++))
        else
            echo -e "  ${GREEN}✓${NC} JWT_SECRET is configured"
        fi
    else
        echo -e "  ${RED}✗${NC} JWT_SECRET not found in .env"
        ((ERRORS++))
    fi
    
    if grep -q "^ENCRYPTION_KEY=" "$INSTALL_DIR/.env"; then
        ENCRYPTION_KEY=$(grep "^ENCRYPTION_KEY=" "$INSTALL_DIR/.env" | cut -d'=' -f2)
        if [ "$ENCRYPTION_KEY" == "CHANGE_THIS_IMMEDIATELY" ] || [ -z "$ENCRYPTION_KEY" ] || [ ${#ENCRYPTION_KEY} -lt 32 ]; then
            echo -e "  ${RED}✗${NC} ENCRYPTION_KEY is not set or too short (minimum 32 characters)"
            ((ERRORS++))
        else
            echo -e "  ${GREEN}✓${NC} ENCRYPTION_KEY is configured"
        fi
    else
        echo -e "  ${RED}✗${NC} ENCRYPTION_KEY not found in .env"
        ((ERRORS++))
    fi
else
    echo -e "  ${RED}✗${NC} .env file not found"
    echo "    Fix: cp env.example .env && edit .env"
    ((ERRORS++))
fi

# Check 3: Frontend dist exists
echo ""
echo -e "${BLUE}[3/8]${NC} Checking frontend..."
if [ -d "$INSTALL_DIR/frontend/dist" ]; then
    if [ -f "$INSTALL_DIR/frontend/dist/index.html" ]; then
        echo -e "  ${GREEN}✓${NC} Frontend dist directory exists"
    else
        echo -e "  ${YELLOW}⚠${NC} Frontend dist exists but index.html not found"
        ((WARNINGS++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Frontend dist directory not found (optional for Docker deployment)"
    ((WARNINGS++))
fi

# Check 4: Docker files (if using Docker)
echo ""
echo -e "${BLUE}[4/8]${NC} Checking Docker configuration..."
if [ -f "$INSTALL_DIR/docker-compose.frontend.yml" ]; then
    echo -e "  ${GREEN}✓${NC} docker-compose.frontend.yml exists"
    
    if command -v docker &> /dev/null; then
        echo -e "  ${GREEN}✓${NC} Docker is installed"
        if docker ps &> /dev/null; then
            echo -e "  ${GREEN}✓${NC} Docker daemon is running"
        else
            echo -e "  ${YELLOW}⚠${NC} Docker daemon is not running"
            ((WARNINGS++))
        fi
    else
        echo -e "  ${YELLOW}⚠${NC} Docker not installed (optional)"
        ((WARNINGS++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} docker-compose.frontend.yml not found (optional)"
    ((WARNINGS++))
fi

# Check 5: Required directories
echo ""
echo -e "${BLUE}[5/8]${NC} Checking directories..."
mkdir -p "$INSTALL_DIR/data"
if [ -d "$INSTALL_DIR/data" ]; then
    echo -e "  ${GREEN}✓${NC} Data directory exists"
else
    echo -e "  ${RED}✗${NC} Cannot create data directory"
    ((ERRORS++))
fi

# Check 6: Port availability
echo ""
echo -e "${BLUE}[6/8]${NC} Checking port availability..."
if command -v lsof &> /dev/null || command -v netstat &> /dev/null; then
    PORT_IN_USE=false
    if command -v lsof &> /dev/null; then
        if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null 2>&1; then
            PORT_IN_USE=true
        fi
    elif command -v netstat &> /dev/null; then
        if netstat -an | grep -q ":8080.*LISTEN"; then
            PORT_IN_USE=true
        fi
    fi
    
    if [ "$PORT_IN_USE" == "true" ]; then
        echo -e "  ${YELLOW}⚠${NC} Port 8080 is already in use"
        echo "    You may need to change SERVER_PORT in .env"
        ((WARNINGS++))
    else
        echo -e "  ${GREEN}✓${NC} Port 8080 is available"
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Cannot check port (lsof/netstat not available)"
    ((WARNINGS++))
fi

# Check 7: Binary test (if possible)
echo ""
echo -e "${BLUE}[7/8]${NC} Testing binary..."
if [ -f "$INSTALL_DIR/unified-admin" ] && [ -x "$INSTALL_DIR/unified-admin" ]; then
    # Try to get version or help
    if "$INSTALL_DIR/unified-admin" --version &> /dev/null || "$INSTALL_DIR/unified-admin" --help &> /dev/null; then
        echo -e "  ${GREEN}✓${NC} Binary is functional"
    else
        echo -e "  ${YELLOW}⚠${NC} Could not verify binary functionality"
        ((WARNINGS++))
    fi
fi

# Check 8: API connectivity (if server is running)
echo ""
echo -e "${BLUE}[8/8]${NC} Checking API connectivity..."
if command -v curl &> /dev/null; then
    if curl -s http://localhost:8080/api/v1/health &> /dev/null; then
        echo -e "  ${GREEN}✓${NC} API server is running and responding"
    else
        echo -e "  ${YELLOW}⚠${NC} API server is not running (this is OK if you haven't started it yet)"
        ((WARNINGS++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} curl not available, skipping API check"
    ((WARNINGS++))
fi

# Summary
echo ""
echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}║              ✓ All checks passed!                         ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "You're ready to start the gateway:"
    echo -e "  ${BLUE}./start.sh${NC} or ${BLUE}./unified-admin${NC}"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}║          ⚠ Warnings found (non-critical)                  ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Found $WARNINGS warning(s). Review above and fix if needed."
    echo "You can still try to start the gateway:"
    echo -e "  ${BLUE}./start.sh${NC} or ${BLUE}./unified-admin${NC}"
    exit 0
else
    echo -e "${RED}║              ✗ Errors found!                                ║${NC}"
    echo -e "${RED}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Found $ERRORS error(s) and $WARNINGS warning(s)."
    echo "Please fix the errors before starting the gateway."
    exit 1
fi

